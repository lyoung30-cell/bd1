# FuelTrack — GitHub Pages App

This folder contains the files to publish FuelTrack on GitHub Pages, with basic installable Progressive Web App support.

## Publish it
1. Unzip `FuelTrack-GitHub-Pages.zip`.
2. Open your GitHub repository and choose **Add file → Upload files**.
3. Upload all files in this folder to the repository root (or the exact folder configured for GitHub Pages): `index.html`, `manifest.webmanifest`, `service-worker.js`, and `icon.svg`. You can also upload this `README.md`.
4. Commit the changes.
5. Go to **Settings → Pages** and select your `main` branch and `/ (root)` if that is where you uploaded the files.
6. Open the website URL shown in Settings → Pages.

## Make it feel like an app
On a compatible phone/browser, open the published website and use **Add to Home Screen** or **Install app** if offered. GitHub Pages hosts the website; it does not publish to an app store.

## Notes
- `index.html` must be in the folder GitHub Pages publishes from.
- Keep the manifest, icon, and service worker alongside `index.html`.
- If the repository already has an `index.html`, replace it only if FuelTrack should become that repository's homepage.
- The app stores meal and water selections in that browser's local storage; they do not automatically sync across devices.
